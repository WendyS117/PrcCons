module com.mycompany.gym {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.gym to javafx.fxml;
    exports com.mycompany.gym;
}
